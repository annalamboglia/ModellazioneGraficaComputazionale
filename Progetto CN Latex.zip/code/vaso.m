clear all; close all; clc;

% Punti di controllo
P =[0 0; -6 0; -3 4; -0.5 6; -0.5 6;  -2 8];

% Generazione della matrice di Bernstein
syms t
B = bernsteinMatrix(length(P(:,1)) - 1, t);
curve = simplify(B*P);

% Plot dei punti di controllo e della curva generata
figure
hold on
grid on
xlim([-6 6])
plot(P(:,1), P(:, 2), '*r')
fplot(curve(1), curve(2), [0 1])
fplot(-curve(1), curve(2), [0 1])