clear all; close all; clc;

R = @(x) 1./(1+25.*x.^2); % Funzione di Rounge

% Funzione di Rounge corretta
x = -1:0.1:1;
y = R(x);               

% Polinomio di Bernstein
P = [x' y'];           % Matrice di punti
syms t
B = bernsteinMatrix(length(x) - 1, t);
curve = simplify(B*P);  % Curva

% Polinomio interpolante di grando length(x) - 1
p = polyfit(x, y, length(x) - 1);
s = linspace(-1,1, 1000);
f = polyval(p,s);

% Chebychev
n = length(x);
k = 0:1:n;
cx = cos((2*k+1)/(n+1) * pi/2);
cy = R(cx);
pc = polyfit(cx, cy, n);
fc = polyval(pc, s);

% Plot delle figure
figure()
grid on
hold on
ylim([-1,1])
fplot(R, [-1,1], 'b')                    % Plot di Rounge tra -1 e 1  
plot(x,y,'o')                            % Plot dei punti di controllo
fplot(curve(1), curve(2), [0 1], 'g');   % Plot del polinomio di Bernstein
plot(s,f, 'r');                          % Plot del polinomio interpolante
plot(s,fc, 'r');                         % Plot Chebychev
plot(cx, cy, 'o')
legend('Funzione di Runge', 'Punti di controllo', 'Polinomio di Bernstein', 'Polinomio di grado n', 'Punti di Chebychev')  


